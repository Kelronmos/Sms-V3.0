/**
 * SWI Student Monitor workflow preflight.
 *
 * This module evaluates a request; it does NOT execute the requested action,
 * authenticate a user, or replace backend authorization. Call it from a trusted
 * server boundary and independently enforce authorization there.
 *
 * PASS ≠ PROVEN ≠ SEALED ≠ PRODUCTION AUTHORIZED.
 */

export type WorkflowDecision = 'PERMIT' | 'HOLD' | 'REJECT' | 'UNKNOWN';

export interface WorkflowPreflightInput {
  operationId: string;
  actorId: string;
  recordId: string;
  policyRevision: string;
  recordRevision: string;
  /** null means not established; false means explicitly not authorized. */
  authorizationEstablished: boolean | null;
  /** null means the evidence check has not been completed. */
  requiredEvidenceSatisfied: boolean | null;
  /** null means revalidation has not been completed. */
  revalidationCurrent: boolean | null;
  evidenceRefs: string[];
}

export interface WorkflowObservation {
  observationId: string;
  event: 'WORKFLOW_PREFLIGHT';
  state: 'OBSERVED';
  operationId: string;
  actorId: string;
  recordId: string;
  policyRevision: string;
  recordRevision: string;
  evidenceRefs: string[];
  decision: WorkflowDecision;
  reasons: string[];
  actionExecuted: false;
  productionAuthorized: false;
}

function hasText(value: unknown): value is string {
  return typeof value === 'string' && value.trim().length > 0;
}

/** Pure preflight decision. It never executes an operation or grants broad access. */
export function evaluateWorkflowPreflight(
  input: WorkflowPreflightInput,
  observationId: string,
): WorkflowObservation {
  const reasons: string[] = [];
  let decision: WorkflowDecision = 'PERMIT';

  const requiredStrings: Array<[keyof WorkflowPreflightInput, unknown]> = [
    ['operationId', input.operationId],
    ['actorId', input.actorId],
    ['recordId', input.recordId],
    ['policyRevision', input.policyRevision],
    ['recordRevision', input.recordRevision],
  ];

  for (const [field, value] of requiredStrings) {
    if (!hasText(value)) {
      reasons.push(`MISSING_REQUIRED_FIELD:${String(field)}`);
    }
  }
  if (!hasText(observationId)) reasons.push('MISSING_OBSERVATION_ID');

  if (reasons.length > 0) {
    decision = 'UNKNOWN';
  } else if (input.authorizationEstablished === false) {
    decision = 'REJECT';
    reasons.push('AUTHORIZATION_EXPLICITLY_NOT_ESTABLISHED');
  } else if (
    input.authorizationEstablished === null ||
    input.requiredEvidenceSatisfied === null ||
    input.revalidationCurrent === null
  ) {
    decision = 'HOLD';
    if (input.authorizationEstablished === null) reasons.push('AUTHORITY_UNKNOWN');
    if (input.requiredEvidenceSatisfied === null) reasons.push('EVIDENCE_CHECK_UNKNOWN');
    if (input.revalidationCurrent === null) reasons.push('REVALIDATION_UNKNOWN');
  } else if (input.requiredEvidenceSatisfied === false) {
    decision = 'HOLD';
    reasons.push('REQUIRED_EVIDENCE_NOT_SATISFIED');
  } else if (input.revalidationCurrent === false) {
    decision = 'HOLD';
    reasons.push('REVALIDATION_REQUIRED');
  } else if (input.evidenceRefs.length === 0) {
    decision = 'HOLD';
    reasons.push('NO_EVIDENCE_REFERENCES');
  } else {
    reasons.push('PREFLIGHT_CONDITIONS_SATISFIED_ONLY');
  }

  return {
    observationId,
    event: 'WORKFLOW_PREFLIGHT',
    state: 'OBSERVED',
    operationId: input.operationId,
    actorId: input.actorId,
    recordId: input.recordId,
    policyRevision: input.policyRevision,
    recordRevision: input.recordRevision,
    evidenceRefs: [...input.evidenceRefs],
    decision,
    reasons,
    actionExecuted: false,
    productionAuthorized: false,
  };
}
