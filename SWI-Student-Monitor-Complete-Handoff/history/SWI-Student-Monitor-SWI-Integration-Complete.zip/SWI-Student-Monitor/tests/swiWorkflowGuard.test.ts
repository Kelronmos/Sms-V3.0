import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluateWorkflowPreflight, type WorkflowPreflightInput } from '../src/services/swiWorkflowGuard.ts';

const validInput = (): WorkflowPreflightInput => ({
  operationId: 'update-assessment',
  actorId: 'teacher-17',
  recordId: 'student-42',
  policyRevision: 'policy-v1',
  recordRevision: 'record-rev-3',
  authorizationEstablished: true,
  requiredEvidenceSatisfied: true,
  revalidationCurrent: true,
  evidenceRefs: ['evidence://assessment/42/3'],
});

test('returns preflight PERMIT only when all declared checks are satisfied', () => {
  const result = evaluateWorkflowPreflight(validInput(), 'OBS-1');
  assert.equal(result.decision, 'PERMIT');
  assert.equal(result.actionExecuted, false);
  assert.equal(result.productionAuthorized, false);
});

test('unknown authority holds instead of permitting', () => {
  const input = validInput(); input.authorizationEstablished = null;
  assert.equal(evaluateWorkflowPreflight(input, 'OBS-2').decision, 'HOLD');
});

test('explicitly absent authorization rejects', () => {
  const input = validInput(); input.authorizationEstablished = false;
  assert.equal(evaluateWorkflowPreflight(input, 'OBS-3').decision, 'REJECT');
});

test('missing evidence holds', () => {
  const input = validInput(); input.requiredEvidenceSatisfied = false;
  assert.equal(evaluateWorkflowPreflight(input, 'OBS-4').decision, 'HOLD');
});

test('stale decision requires revalidation', () => {
  const input = validInput(); input.revalidationCurrent = false;
  const result = evaluateWorkflowPreflight(input, 'OBS-5');
  assert.equal(result.decision, 'HOLD');
  assert.ok(result.reasons.includes('REVALIDATION_REQUIRED'));
});

test('missing evidence references holds even if evidence check was marked true', () => {
  const input = validInput(); input.evidenceRefs = [];
  assert.equal(evaluateWorkflowPreflight(input, 'OBS-6').decision, 'HOLD');
});

test('missing identity or revision fields yields UNKNOWN', () => {
  const input = validInput(); input.recordRevision = ' ';
  assert.equal(evaluateWorkflowPreflight(input, 'OBS-7').decision, 'UNKNOWN');
});

test('records observation only and copies evidence references', () => {
  const input = validInput();
  const result = evaluateWorkflowPreflight(input, 'OBS-8');
  input.evidenceRefs.push('later-change');
  assert.deepEqual(result.evidenceRefs, ['evidence://assessment/42/3']);
  assert.equal(result.state, 'OBSERVED');
});
