# Student Monitor Observations and Claims — Minimal Contract

This contract separates captured events from interpretations about those events.

## Observation

An observation records a bounded event: identifier, event type, state, relevant operation/record revision, evidence references, and result. It should not declare that an actor was authorized merely because a request was received.

## Claim

A claim references one or more observation IDs and has an explicit status such as `NOT_PROVEN`, `TESTED`, or `PROVEN` only when the applicable proof standard and supporting evidence exist. A status must not be automatically promoted from `PASS`, a hash, a signature, or CI success.

## Invariants

- DATA ≠ EVIDENCE ≠ ADMISSION ≠ AUTHORIZATION ≠ ACTION
- OBSERVATION ≠ CLAIM
- UNKNOWN ≠ FALSE ≠ PERMITTED
- HASH ≠ AUTHORITY ≠ TRUTH
- PASS ≠ PROVEN ≠ SEALED ≠ PRODUCTION AUTHORIZED
- A preflight record does not prove that an operation executed.
- Claims reference observation IDs; observations do not grant authority.

The current `swiWorkflowGuard` emits a preflight observation only. It does not yet implement a durable append-only event store, cryptographic signing, or a complete claims/reporting service.
