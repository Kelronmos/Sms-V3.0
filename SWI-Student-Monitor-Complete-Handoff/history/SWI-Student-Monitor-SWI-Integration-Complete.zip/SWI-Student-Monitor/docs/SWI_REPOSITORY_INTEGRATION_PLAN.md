# SWI Student Monitor — Repository Integration Plan

**Status:** DESIGN + LIMITED PREFLIGHT PROTOTYPE; not a security audit, seal, or production authorization.

## Purpose

Strengthen Student Monitor by adapting relevant contracts and testing disciplines from the public SWI repositories without copying entire repositories, silently changing their baselines, or treating their status as transferable proof.

## Reference repositories checked

- `Kelronmos/SWI-V1-Module-1-10` — README identifies the current reference implementation as V1.1 / Modules 00–11 and describes bounded source admission, replay, change control, evidence export, and adversarial suites. Its README explicitly leaves Foundation Seal 5 not ready, Universal Gate not proven, FM-005–013 open, and legal/regulatory compliance unclaimed.
- `Kelronmos/SWI-V2-Modules-11-22` — README documents M11 as sealed at its stated evidence tip, M12–22 open for controlled development, S9 not proven, durable replay not implemented, and production authorization false.
- `Kelronmos/Structured-Workflow-Intelligence` — broader SWI Core reference; repository descriptions and labels are not independent proof of every behavior.

The references are guidance. Student Monitor must establish its own dependency mapping, tests, evidence, and limitations.

## Integration principles

1. Preserve the existing Student Monitor structure and user-facing workflows where possible.
2. Treat the existing repository baseline as the starting point; record the commit and test outcomes before changes.
3. Prefer small adapters and explicit contracts over copying entire SWI modules.
4. Enforce permissions at a trusted server boundary; UI visibility is not authorization.
5. `UNKNOWN` must never be treated as permission.
6. An observation records what the software observed; a claim interprets it. A claim is not automatically proven by a successful test, signature, hash, or green CI result.
7. A preflight `PERMIT` is not execution, not broad authorization, and not production approval.
8. Never report a test as passing unless it was actually executed and its result recorded.

## Integration matrix

| Student Monitor concern | SWI reference pattern | Proposed application treatment | Evidence required |
|---|---|---|---|
| Student-record change | V1 source admission / change control | Validate actor, record revision, policy revision, and required evidence before trusted server mutation | Tests for stale revisions, missing evidence, unauthorized actor, and concurrent changes |
| Assessment / incident workflow | V2 governing-permit concept | Use operation-scoped preflight and server-side enforcement | Positive and negative tests for each protected operation |
| Record continuity | V2 M11 continuity concept | Link event records to record/policy revisions; do not infer truth from continuity | Tamper/change tests and replay/reconstruction checks |
| AI/CEK output | SWI evidence/authority distinctions | Advisory-only by default; no score independently authorizes a consequential action | Tests proving AI score/status cannot bypass permission checks |
| PDF/JSON exports | V1 evidence-export pattern | Export provenance, scope, timestamps, revisions, and limitations; minimize sensitive data | Round-trip schema validation and tamper-detection tests |
| Startup and CI | Existing package/CI | Locked dependency installation, typecheck, build, focused tests, and honest status report | Captured logs and exact commit SHA |

## Proposed stages

1. Baseline inventory: exact commit, lockfile, existing tests, app routes, API endpoints, database rules, and deployment model.
2. Security boundary map: identify all consequential mutations and the actual backend enforcement point for each.
3. Primitive correction: remove custom hash-as-signature behavior and insecure randomness from security-sensitive code; use vetted cryptographic APIs and managed keys.
4. Workflow guard integration: call the pure preflight from trusted server handlers, then independently enforce authorization and validate current record/policy revisions.
5. Evidence/reporting: structured observations and claims with references and explicit status/limitations.
6. Adversarial verification: unauthorized access, unknown authority, stale state, replay, tampering, malformed input, missing evidence, partial failure, and alternate-route bypasses.
7. Release gate: clean locked install, typecheck, build, all tests, configuration review, privacy review, and deployment-specific checks.

## Current implementation in this package

`src/services/swiWorkflowGuard.ts` is a pure preflight decision helper. It returns an observation and never executes the requested operation. Its `PERMIT` result only means the supplied preflight fields satisfied this helper's narrow conditions. The caller must not use it as the sole authorization control.

The focused test file is `tests/swiWorkflowGuard.test.ts`; run it with `npm run test:swi-guard` after installing the locked dependencies.

## Explicit non-claims

- This package is not independently security audited.
- No full integration of the guard into all backend routes is claimed by adding the helper alone.
- No independent SWI seal is created or inherited.
- No legal/regulatory compliance is claimed.
- No production authorization is granted.
- CI green, if achieved, is not a security proof.
