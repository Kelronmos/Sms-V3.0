# SWI Student Monitor — Initial Security Gap Register

**Scope:** Source-level observations from a limited inspection. This is not a complete audit. Each item needs reproduction and verification against the current commit before it can be closed.

| ID | Area | Initial observation | Risk / boundary | Required action | Closure evidence |
|---|---|---|---|---|---|
| SM-GAP-001 | `src/services/swiCore.ts` | `verifyHash()` compares a supplied string to a constant identifier; it does not hash or verify source artifacts. | Integrity label may be mistaken for actual code integrity. | Rename/restrict this check or implement verifiable, version-bound integrity metadata where justified. | Tests show modified artifact is detected; limitations documented. |
| SM-GAP-002 | `src/services/swiModuleSecurity.ts` | Custom FNV-like expansion is described as a SHA-256 simulation; it is not SHA-256 or a secure signature scheme. | Forgery risk if treated as cryptographic authentication. | Remove from security-sensitive paths; use vetted Web Crypto/Node crypto APIs and an explicit key lifecycle. | Known test vectors, invalid-signature tests, key separation and rotation tests. |
| SM-GAP-003 | `src/services/swiModuleSecurity.ts` | Random fallback uses `Math.random()` when secure randomness is unavailable. | Predictable tokens if used for security. | Fail closed when a cryptographically secure RNG is unavailable. | Tests for no insecure fallback and token unpredictability assumptions documented. |
| SM-GAP-004 | `src/services/swiModuleSecurity.ts` | Time window is checked, but a token cache / unique nonce consumption mechanism is not apparent in the inspected code. | A message may be replayed within the time window. | Add server-side replay state or an equivalent single-use request identifier strategy. | Replayed identical request rejected in integration tests. |
| SM-GAP-005 | `src/services/AdvancedCEK.ts` | Text keyword heuristics and cosine similarity generate Green/Yellow/Red labels; the header says “Production Grade.” | A heuristic score could be over-trusted as proof or authorization. | Label as advisory/prototype; prohibit score from authorizing consequential operations. | Tests show each consequential route enforces independent authority checks. |
| SM-GAP-006 | Backend authorization | Full route-by-route enforcement was not established by this limited review. | UI roles may not protect direct API calls. | Inventory all sensitive endpoints and verify authorization at the server boundary. | Endpoint matrix and negative tests for every protected route. |
| SM-GAP-007 | Reports and exports | Presence of PDF/report generation does not establish authenticity, completeness, or tamper resistance. | Users may over-trust exported records. | Include scope, revisions, provenance and limitations; validate schemas and minimize sensitive data. | Export validation and tamper/change tests. |
| SM-GAP-008 | Privacy / student data | This review did not assess the full data lifecycle, access rules, retention, backups, or deployment secrets. | Sensitive student data exposure. | Conduct dedicated privacy and deployment review before production use. | Documented review and verified configuration. |

## State rules

Do not close a gap because a code change exists. Close it only after the relevant adversarial test is run and the result is tied to an exact commit. `IMPLEMENTED` ≠ `TESTED` ≠ `PROVEN` ≠ `SEALED` ≠ `PRODUCTION AUTHORIZED`.
