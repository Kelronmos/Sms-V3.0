@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title SWI Student Monitor Launcher

echo ======================================================
echo   SWI STUDENT MONITOR - ONE-CLICK LOCAL LAUNCHER
echo ======================================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js 20 or newer is required.
  echo Install Node.js once, then run this file again.
  pause
  exit /b 1
)
where npm >nul 2>nul
if errorlevel 1 (
  echo ERROR: npm was not found. Repair the Node.js installation.
  pause
  exit /b 1
)

for /f "tokens=1 delims=.v" %%V in ('node -p "process.versions.node"') do set NODE_MAJOR=%%V
if not defined NODE_MAJOR set NODE_MAJOR=0
if %NODE_MAJOR% LSS 20 (
  echo ERROR: Node.js 20+ required. Detected:
  node -v
  pause
  exit /b 1
)

if not exist package-lock.json (
  echo ERROR: package-lock.json is missing. Refusing an unpinned install.
  pause
  exit /b 1
)

if not exist node_modules\.bin\vite.cmd goto INSTALL_DEPS
if not exist node_modules\.bin\tsx.cmd goto INSTALL_DEPS
if not exist node_modules\better-sqlite3 goto INSTALL_DEPS
goto BUILD_APP

:INSTALL_DEPS
echo Dependencies are missing or incomplete.
echo First setup requires internet access to download the locked packages.
echo Later launches can run without internet while node_modules is retained.
call npm ci
if errorlevel 1 (
  echo.
  echo ERROR: dependency installation failed. No server was started.
  echo Connect to the internet for first setup, then retry.
  pause
  exit /b 1
)

:BUILD_APP
echo.
echo [1/3] Rebuilding the browser application from source...
call npm run build
if errorlevel 1 (
  echo ERROR: build failed. The server was not started.
  pause
  exit /b 1
)

if exist .swi-monitor.pid del .swi-monitor.pid >nul 2>nul

echo.
echo [2/3] Starting local SWI server on http://127.0.0.1:3000 ...
start "SWI Student Monitor Server" /min cmd /k "cd /d ""%~dp0"" && set NODE_ENV=production && node --import tsx server.ts"

set /a ATTEMPTS=0
:WAIT_FOR_SERVER
set /a ATTEMPTS+=1
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 http://127.0.0.1:3000/api/health; if ($r.StatusCode -eq 200) { exit 0 } else { exit 1 } } catch { exit 1 }" >nul 2>nul
if not errorlevel 1 goto SERVER_READY
if %ATTEMPTS% GEQ 30 goto SERVER_FAILED
timeout /t 1 /nobreak >nul
goto WAIT_FOR_SERVER

:SERVER_READY
echo.
echo [3/3] Opening SWI Student Monitor in your default browser.
start "" "http://127.0.0.1:3000"
echo.
echo ======================================================
echo   READY: http://127.0.0.1:3000
echo   Local server and SQLite data run on this computer.
echo   Demo/local features can work without internet.
echo   Firebase, Google/Apple sign-in, cloud AI, remote
echo   images and cloud sync need an internet connection.
echo   Keep the server window open while using the app.
echo   Close that server window to stop the app.
echo ======================================================
echo.
pause
exit /b 0

:SERVER_FAILED
echo ERROR: Server did not become ready within 30 seconds.
echo Check the minimized SWI Student Monitor Server window for details.
echo If port 3000 is already in use, close the other process and retry.
pause
exit /b 1
