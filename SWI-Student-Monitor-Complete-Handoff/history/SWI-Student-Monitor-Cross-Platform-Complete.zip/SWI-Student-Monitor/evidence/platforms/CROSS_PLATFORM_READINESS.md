# Cross-platform readiness record

Date: 2026-10-17

## Changes present in source

- Shared web/PWA source retained.
- Added Capacitor configuration and optional mobile toolchain setup script.
- Added Electron desktop scaffolding and package targets for Windows, macOS, and Linux.
- Added macOS and Linux local launchers alongside the existing Windows launcher.
- Added a Device panel integrated into the signed-in application shell.
- Device panel explicitly requests user action for one-time location, camera preview, motion, and vibration checks; it stops camera streams and removes motion listeners when closed.
- Added device capability matrix, platform build guide, component integration matrix, and privacy boundaries.
- Local launchers bind the Express server to loopback rather than exposing it to the local network.

## Executed checks

- `package.json`, `package-lock.json`, and optional platform manifest JSON parsing: PASS.
- Package dependency declarations match the existing lockfile: PASS.
- `node --check electron/main.cjs`: PASS.
- `node --check scripts/setup-platforms.mjs`: PASS.
- `node --check scripts/build-native.mjs`: PASS.
- SWI workflow guard suite using Node.js built-in test runner: **8 passed, 0 failed**.

## Not verified

- Full TypeScript check and Vite build: NOT RUN; dependencies are not installed in this environment.
- Optional Capacitor/Electron dependency installation: NOT COMPLETED; package registry installation timed out.
- Android build on Android SDK/Gradle: NOT RUN.
- iOS build on macOS/Xcode: NOT RUN.
- Windows/macOS/Linux packaged desktop installers: NOT RUN.
- Real-device permissions/sensor testing: NOT RUN.
- End-to-end offline test and native mobile API parity: NOT VERIFIED.

## Critical integration limits

The app's existing Express + `better-sqlite3` backend runs locally on desktop. It cannot automatically run inside a Capacitor Android/iOS WebView. Many components call relative `/api/...` routes, so mobile needs an explicit authenticated HTTPS API base and/or a native local persistence adapter before all backend-connected features can work on mobile. Bluetooth LE, NFC, health/step-count APIs, biometrics, background sensors, and native sharing are not wired to application workflows by this change.

No production authorization, security certification, platform seal, or complete cross-platform parity is claimed.
