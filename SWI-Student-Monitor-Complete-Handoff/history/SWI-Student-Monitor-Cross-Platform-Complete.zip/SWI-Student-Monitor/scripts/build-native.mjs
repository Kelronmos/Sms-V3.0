import { spawnSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import process from 'node:process';
const platform = process.argv[2];
if (!['android', 'ios'].includes(platform)) {
  console.error('Usage: node scripts/build-native.mjs android|ios'); process.exit(2);
}
const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
const npx = process.platform === 'win32' ? 'npx.cmd' : 'npx';
function run(command, args) {
  const r = spawnSync(command, args, { stdio: 'inherit', shell: process.platform === 'win32' });
  if (r.status !== 0) process.exit(r.status ?? 1);
}
run(npm, ['run', 'build']);
run(process.execPath, ['scripts/setup-platforms.mjs', 'mobile']);
if (!existsSync(platform)) run(npx, ['cap', 'add', platform]);
run(npx, ['cap', 'sync', platform]);
run(npx, ['cap', 'open', platform]);
