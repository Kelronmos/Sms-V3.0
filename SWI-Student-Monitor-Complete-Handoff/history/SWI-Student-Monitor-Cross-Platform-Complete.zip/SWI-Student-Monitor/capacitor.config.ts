import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.trustsmotion.swi.studentmonitor',
  appName: 'SWI Student Monitor',
  webDir: 'dist',
  bundledWebRuntime: false,
  ios: { contentInset: 'automatic', allowsLinkPreview: false },
  android: { allowMixedContent: false },
  server: {
    // Do not set server.url here: the native app should load its bundled, offline-capable web assets.
    cleartext: false,
  },
};
export default config;
