# One-click / offline readiness record

Date: 2026-10-17

## Implemented in this package

- `start.bat` checks Node/npm and locked dependency files, installs locked dependencies when missing, rebuilds the frontend, starts the production-mode local server, waits for `/api/health`, and opens the browser.
- The server exposes `/api/health` and supports a `PORT` environment variable.
- PWA Workbox precaches matching built HTML/JS/CSS/static assets and provides an SPA navigation fallback.
- The Google Fonts CSS import was removed so the base UI does not depend on downloading fonts.
- A local synthetic demo login no longer requires Firebase to be reachable. Restoring a saved local session skips Firebase synchronization while offline.
- The application shows an offline notice explaining that cloud functions are unavailable.
- Local/offline scope and first-run requirements are documented in `docs/OFFLINE_AND_ONE_CLICK_START.md`.

## Verification results

- SWI workflow guard tests executed with Node.js built-in test runner and experimental TypeScript stripping: **8 passed, 0 failed**.
- Package/lockfile JSON and declared dependency consistency: PASS.
- Full `npm ci`, Vite production build, full TypeScript check, server startup, browser launch, and real offline-browser/PWA test: **NOT VERIFIED** in this environment because dependency installation did not complete before the execution timeout.

## Boundaries

This is an offline-capable local prototype. It does not make Firebase Auth/Firestore, Google/Apple sign-in, cloud AI, or remote APIs work without internet. First-time dependency installation requires internet unless dependencies are already available locally. PWA cache supports app-shell assets; it is not a backup or a guarantee that every workflow is offline-ready. No production authorization is claimed.
