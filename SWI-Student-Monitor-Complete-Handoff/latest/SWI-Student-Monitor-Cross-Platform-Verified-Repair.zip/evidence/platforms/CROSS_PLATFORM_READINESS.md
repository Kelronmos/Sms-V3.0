# Cross-platform readiness record

Date: 2026-10-17

## Changes present in source

- Shared web/PWA source retained.
- Added Capacitor configuration and optional mobile toolchain setup script.
- Added Electron desktop scaffolding and package targets for Windows, macOS, and Linux.
- Added macOS and Linux local launchers alongside the existing Windows launcher.
- Added a Device panel integrated into the signed-in application shell.
- Device panel explicitly requests user action for one-time location, camera preview, motion, and vibration checks; it stops camera streams and removes motion listeners when closed.
- Added device capability matrix, platform build guide, component integration matrix, and privacy boundaries.
- Local launchers bind the Express server to loopback rather than exposing it to the local network.

## Executed checks

- `package.json`, `package-lock.json`, and optional platform manifest JSON parsing: PASS.
- Package dependency declarations match the existing lockfile: PASS.
- `node --check electron/main.cjs`: PASS.
- `node --check scripts/setup-platforms.mjs`: PASS.
- `node --check scripts/build-native.mjs`: PASS.
- `node --check scripts/verify-build-environment.mjs`: PASS.
- `node --check scripts/verify-offline-shell.mjs`: PASS.
- TypeScript parser scan: 61 `.ts`/`.tsx` files, 0 syntax/parse errors (this is not a type check).
- SWI workflow guard suite using `node --experimental-strip-types --test tests/swiWorkflowGuard.test.ts`: **8 passed, 0 failed**.
- Build-environment check: Node/npm/Java available; project dependencies incomplete; Android SDK environment variables absent; Xcode unavailable on this Linux runner.
- SWI workflow guard suite using Node.js built-in test runner: **8 passed, 0 failed**.

## Not verified

- Full TypeScript check: ATTEMPTED but BLOCKED because dependency installation did not complete; registry requests failed with `EAI_AGAIN`. The compiler reported missing type-definition packages, so no clean typecheck result is claimed.
- Full Vite application build: NOT VERIFIED because dependencies are unavailable.
- Optional Capacitor/Electron dependency installation: NOT COMPLETED; package registry requests failed with `EAI_AGAIN`.
- Android debug APK build: NOT RUN; Android SDK is not installed/configured in this runner. The build script now invokes Gradle `assembleDebug` instead of merely opening Android Studio.
- iOS Simulator build: NOT RUN; this runner is Linux and does not have Xcode. The build script now invokes `xcodebuild` on macOS rather than merely opening Xcode.
- Windows/macOS/Linux packaged desktop installers: NOT RUN; OS-specific packaging requires each platform runner. A GitHub Actions matrix was added to build and upload artifacts on supported runners.
- Real-device permissions/sensor testing: NOT RUN; a repeatable physical-device test plan was added.
- Complete offline operation: NOT VERIFIED; an offline test plan and a post-build PWA shell-artifact check were added. The latter does not prove application workflows work offline.

## Critical integration limits

The app's existing Express + `better-sqlite3` backend runs locally on desktop. It cannot automatically run inside a Capacitor Android/iOS WebView. Many components call relative `/api/...` routes, so mobile needs an explicit authenticated HTTPS API base and/or a native local persistence adapter before all backend-connected features can work on mobile. Bluetooth LE, NFC, health/step-count APIs, biometrics, background sensors, and native sharing are not wired to application workflows by this change.

No production authorization, security certification, platform seal, or complete cross-platform parity is claimed. A GitHub Actions workflow now defines full typecheck/web build, Android debug APK, iOS Simulator build, and OS-specific desktop package jobs; their results remain PENDING until the workflow actually runs.
