// Keep this config free of optional-toolchain type imports so the web TypeScript
// check can run before the Capacitor CLI is installed. Capacitor validates it at sync time.
const config = {
  appId: 'com.trustsmotion.swi.studentmonitor',
  appName: 'SWI Student Monitor',
  webDir: 'dist',
  bundledWebRuntime: false,
  ios: { contentInset: 'automatic', allowsLinkPreview: false },
  android: { allowMixedContent: false },
  server: {
    // Do not set server.url here: the native app should load its bundled, offline-capable web assets.
    cleartext: false,
  },
};
export default config;
