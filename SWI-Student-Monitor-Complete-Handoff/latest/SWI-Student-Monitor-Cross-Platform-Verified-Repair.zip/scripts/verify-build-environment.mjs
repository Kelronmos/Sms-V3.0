import { existsSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import process from 'node:process';

const checks = [
  ['Node.js >= 20', () => Number(process.versions.node.split('.')[0]) >= 20, process.version],
  ['npm >= 10', () => { const r = spawnSync(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['--version'], { encoding: 'utf8', shell: process.platform === 'win32' }); return !r.error && r.status === 0 && Number(r.stdout.trim().split('.')[0]) >= 10; }, 'npm version'],
  ['Dependencies installed', () => existsSync('node_modules/typescript/bin/tsc') && existsSync('node_modules/vite/bin/vite.js'), 'TypeScript and Vite package files'],
  ['Android SDK tools', () => Boolean(process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT), 'ANDROID_HOME or ANDROID_SDK_ROOT'],
  ['Java', () => spawnSync('java', ['-version'], { stdio: 'ignore', shell: process.platform === 'win32' }).status === 0, 'java -version'],
  ['Xcode (macOS only)', () => process.platform !== 'darwin' || spawnSync('xcodebuild', ['-version'], { stdio: 'ignore' }).status === 0, process.platform === 'darwin' ? 'xcodebuild -version' : 'not available on this OS'],
];
let failed = false;
for (const [name, test, detail] of checks) {
  let ok = false;
  try { ok = Boolean(test()); } catch { ok = false; }
  console.log(`${ok ? 'PASS' : 'NOT READY'} | ${name} | ${detail}`);
  if (!ok) failed = true;
}
console.log(failed ? '\nEnvironment is not ready for all requested builds.' : '\nBasic build environment checks passed. This is not a build/test result.');
process.exitCode = failed ? 1 : 0;
