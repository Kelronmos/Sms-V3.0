import { spawnSync } from 'node:child_process';
import process from 'node:process';
const target = process.argv[2] || 'all';
const mobile = [
  '@capacitor/core@^7.4.3', '@capacitor/cli@^7.4.3', '@capacitor/android@^7.4.3', '@capacitor/ios@^7.4.3',
  '@capacitor/camera@^7.0.2', '@capacitor/device@^7.0.2', '@capacitor/geolocation@^7.1.5',
  '@capacitor/haptics@^7.0.2', '@capacitor/network@^7.0.2', '@capacitor/preferences@^7.0.2', '@capacitor/filesystem@^7.1.4'
];
const desktop = ['electron@^37.2.6', 'electron-builder@^26.0.12'];
const packages = target === 'mobile' ? mobile : target === 'desktop' ? desktop : target === 'all' ? [...mobile, ...desktop] : null;
if (!packages) { console.error('Usage: node scripts/setup-platforms.mjs [all|mobile|desktop]'); process.exit(2); }
const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
console.log(`Installing optional ${target} build toolchain. Internet access is required for first setup.`);
const result = spawnSync(npm, ['install', '--save-dev', ...packages], { stdio: 'inherit', shell: process.platform === 'win32' });
if (result.status !== 0) process.exit(result.status ?? 1);
console.log('Optional build tools installed and package-lock.json updated. Re-run typecheck and tests before building native packages.');
