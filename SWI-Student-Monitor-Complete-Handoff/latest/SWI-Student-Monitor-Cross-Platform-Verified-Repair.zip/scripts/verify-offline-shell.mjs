import { existsSync, readFileSync, readdirSync } from 'node:fs';
import path from 'node:path';

const failures = [];
const dist = path.resolve('dist');
function check(label, condition, detail) {
  console.log(`${condition ? 'PASS' : 'FAIL'} | ${label}${detail ? ` | ${detail}` : ''}`);
  if (!condition) failures.push(label);
}
check('Built dist directory exists', existsSync(dist), dist);
const indexPath = path.join(dist, 'index.html');
check('Offline app-shell entry exists', existsSync(indexPath), 'dist/index.html');
let html = '';
if (existsSync(indexPath)) html = readFileSync(indexPath, 'utf8');
check('Built entry references bundled assets', /\.\/(assets|assets\/)/.test(html) || /\/assets\//.test(html), 'index.html asset reference');
const files = existsSync(dist) ? readdirSync(dist, { recursive: true }).map(String) : [];
check('Service worker generated', files.some((file) => /(^|\/)sw\.js$/.test(file) || /service-worker/i.test(file)), 'Workbox/PWA output');
check('Web manifest generated', files.some((file) => /manifest.*\.webmanifest$|manifest\.json$/.test(file)), 'PWA manifest output');
console.log('\nLIMITATION: This checks that the app shell and PWA artifacts were generated. It does not prove all screens, API writes, login, cloud services, mobile APIs, or conflict resolution work offline.');
if (failures.length) process.exitCode = 1;
