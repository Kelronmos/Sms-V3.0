import { spawnSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import path from 'node:path';
import process from 'node:process';

const platform = process.argv[2];
if (!['android', 'ios'].includes(platform)) {
  console.error('Usage: node scripts/build-native.mjs android|ios');
  process.exit(2);
}

function run(command, args, options = {}) {
  console.log(`\n> ${command} ${args.join(' ')}`);
  const result = spawnSync(command, args, {
    stdio: 'inherit',
    shell: process.platform === 'win32',
    ...options,
  });
  if (result.error) {
    console.error(`Unable to run ${command}: ${result.error.message}`);
    process.exit(1);
  }
  if (result.status !== 0) process.exit(result.status ?? 1);
}

function requireCommand(command, help) {
  const probe = spawnSync(command, ['--version'], { encoding: 'utf8', shell: process.platform === 'win32' });
  if (probe.error || probe.status !== 0) {
    console.error(`${command} is required. ${help}`);
    process.exit(1);
  }
}

if (platform === 'ios' && process.platform !== 'darwin') {
  console.error('iOS native builds require macOS with Xcode installed. The iOS project can be generated/synced elsewhere, but this script intentionally stops before claiming a native build.');
  process.exit(2);
}

run('npm', ['run', 'build']);
run(process.execPath, ['scripts/setup-platforms.mjs', 'mobile']);

const cap = process.platform === 'win32' ? 'npx.cmd' : 'npx';
if (!existsSync(platform)) run(cap, ['cap', 'add', platform]);
run(cap, ['cap', 'sync', platform]);

if (platform === 'android') {
  const wrapper = path.join('android', process.platform === 'win32' ? 'gradlew.bat' : 'gradlew');
  if (!existsSync(wrapper)) {
    console.error(`Android Gradle wrapper not found at ${wrapper}. Check that Capacitor Android was added successfully.`);
    process.exit(1);
  }
  if (process.platform !== 'win32') run('chmod', ['+x', wrapper]);
  requireCommand('java', 'Install a supported JDK and configure JAVA_HOME.');
  run(process.platform === 'win32' ? 'gradlew.bat' : './gradlew', ['assembleDebug'], { cwd: 'android' });
  console.log('\nANDROID BUILD COMPLETE: android/app/build/outputs/apk/debug/app-debug.apk');
} else {
  requireCommand('xcodebuild', 'Install Xcode and its command-line tools.');
  const workspace = path.join('ios', 'App', 'App.xcworkspace');
  if (!existsSync(workspace)) {
    console.error(`Xcode workspace not found at ${workspace}. Check that Capacitor iOS was added successfully.`);
    process.exit(1);
  }
  run('xcodebuild', [
    '-workspace', workspace,
    '-scheme', 'App',
    '-configuration', 'Debug',
    '-sdk', 'iphonesimulator',
    '-destination', 'generic/platform=iOS Simulator',
    'CODE_SIGNING_ALLOWED=NO',
    'build',
  ]);
  console.log('\niOS SIMULATOR BUILD COMPLETE. This does not create a signed App Store archive or verify physical-device sensors.');
}
