@echo off
setlocal
cd /d "%~dp0"
echo SWI Student Monitor - cross-platform build orchestrator
where node >nul 2>nul || (echo Node.js 20+ required & exit /b 1)
if not exist node_modules\.bin\vite.cmd npm ci
if errorlevel 1 exit /b 1
call npm run build
if errorlevel 1 exit /b 1
echo Web/PWA build complete.
echo Native Android/iOS and desktop builds require their platform toolchains.
echo Run npm run build:android, npm run build:ios, npm run build:desktop:win, or npm run build:desktop:mac as appropriate.
