/**
 * SWI Student Monitor device capability adapter.
 * Capability checks are informational. Access is requested only after an explicit user action.
 * No sensor is sampled in the background by this module.
 */
export type CapabilityState = 'available' | 'permission-required' | 'unsupported' | 'unknown';
export type DeviceCapability = {
  id: string;
  label: string;
  state: CapabilityState;
  note: string;
};

export function getDeviceCapabilities(): DeviceCapability[] {
  const n = navigator as Navigator & {
    bluetooth?: unknown;
    nfc?: unknown;
    wakeLock?: unknown;
    getBattery?: () => Promise<unknown>;
  };
  const win = window as Window & {
    DeviceMotionEvent?: typeof DeviceMotionEvent & { requestPermission?: () => Promise<string> };
    DeviceOrientationEvent?: typeof DeviceOrientationEvent & { requestPermission?: () => Promise<string> };
  };
  return [
    { id: 'network', label: 'Network status', state: 'available', note: 'Online/offline state only; does not identify networks.' },
    { id: 'geolocation', label: 'Location', state: 'geolocation' in navigator ? 'permission-required' : 'unsupported', note: 'Requires explicit permission and HTTPS or localhost.' },
    { id: 'camera', label: 'Camera', state: navigator.mediaDevices?.getUserMedia ? 'permission-required' : 'unsupported', note: 'Camera is opened only after a user action; no automatic recording.' },
    { id: 'microphone', label: 'Microphone', state: navigator.mediaDevices?.getUserMedia ? 'permission-required' : 'unsupported', note: 'Microphone is opened only after a user action; no automatic recording.' },
    { id: 'motion', label: 'Motion / accelerometer', state: win.DeviceMotionEvent ? 'permission-required' : 'unsupported', note: 'Browser/device dependent; iOS may require a gesture-based permission request.' },
    { id: 'orientation', label: 'Device orientation', state: win.DeviceOrientationEvent ? 'permission-required' : 'unsupported', note: 'Browser/device dependent; readings are not identity or attendance proof.' },
    { id: 'vibration', label: 'Haptics / vibration', state: 'vibrate' in navigator ? 'available' : 'unsupported', note: 'Availability varies; vibration is used only on request.' },
    { id: 'battery', label: 'Battery status', state: n.getBattery ? 'permission-required' : 'unsupported', note: 'Not supported by many browsers, including some mobile browsers.' },
    { id: 'bluetooth', label: 'Bluetooth LE', state: n.bluetooth ? 'permission-required' : 'unsupported', note: 'Usually Chromium/Android-focused; not universally supported on iOS or desktop.' },
    { id: 'nfc', label: 'NFC', state: n.nfc ? 'permission-required' : 'unsupported', note: 'Web NFC support is limited; no silent tag reading.' },
    { id: 'wake-lock', label: 'Keep screen awake', state: n.wakeLock ? 'available' : 'unsupported', note: 'Optional; only while a user-visible task requires it.' },
  ];
}

export async function requestCurrentLocation(): Promise<{ latitude: number; longitude: number; accuracy: number }> {
  if (!('geolocation' in navigator)) throw new Error('LOCATION_UNSUPPORTED');
  return new Promise((resolve, reject) => navigator.geolocation.getCurrentPosition(
    (p) => resolve({ latitude: p.coords.latitude, longitude: p.coords.longitude, accuracy: p.coords.accuracy }),
    (e) => reject(new Error(`LOCATION_${e.code}`)),
    { enableHighAccuracy: false, timeout: 10000, maximumAge: 60000 },
  ));
}

export async function requestCameraPreview(video: HTMLVideoElement): Promise<MediaStream> {
  if (!navigator.mediaDevices?.getUserMedia) throw new Error('CAMERA_UNSUPPORTED');
  const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
  video.srcObject = stream;
  await video.play();
  return stream;
}

export function stopMediaStream(stream?: MediaStream | null): void {
  stream?.getTracks().forEach((track) => track.stop());
}

export async function requestMotionPermission(): Promise<void> {
  const motion = (window as any).DeviceMotionEvent;
  if (!motion) throw new Error('MOTION_UNSUPPORTED');
  if (typeof motion.requestPermission === 'function') {
    const result = await motion.requestPermission();
    if (result !== 'granted') throw new Error('MOTION_PERMISSION_DENIED');
  }
}

export function requestVibration(): boolean {
  if (!('vibrate' in navigator)) return false;
  return navigator.vibrate(80);
}
