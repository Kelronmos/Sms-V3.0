import React, { useEffect, useRef, useState } from 'react';
import { getDeviceCapabilities, requestCameraPreview, requestCurrentLocation, requestMotionPermission, requestVibration, stopMediaStream } from '../../platform/deviceCapabilities';
import type { DeviceCapability } from '../../platform/deviceCapabilities';

export function DeviceCapabilitiesPanel({ onClose }: { onClose: () => void }) {
  const [capabilities, setCapabilities] = useState<DeviceCapability[]>([]);
  const [message, setMessage] = useState('No sensor is active. Choose a capability to request access.');
  const [location, setLocation] = useState<string>('');
  const [motion, setMotion] = useState<string>('Not sampled');
  const [cameraActive, setCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    setCapabilities(getDeviceCapabilities());
    const update = () => setCapabilities(getDeviceCapabilities());
    window.addEventListener('online', update);
    window.addEventListener('offline', update);
    return () => {
      window.removeEventListener('online', update);
      window.removeEventListener('offline', update);
      stopMediaStream(streamRef.current);
      window.removeEventListener('devicemotion', handleMotion);
    };
  }, []);

  function handleMotion(event: DeviceMotionEvent) {
    const a = event.accelerationIncludingGravity;
    setMotion(a ? `x ${a.x?.toFixed(2) ?? '—'}, y ${a.y?.toFixed(2) ?? '—'}, z ${a.z?.toFixed(2) ?? '—'}` : 'No readings reported by device');
  }

  async function useCapability(id: string) {
    try {
      if (id === 'geolocation') {
        const result = await requestCurrentLocation();
        setLocation(`Approx. ${Math.round(result.accuracy)} m accuracy`);
        setMessage('Location permission granted for this one-time request. Coordinates were not saved or sent.');
      } else if (id === 'camera') {
        if (cameraActive) {
          stopMediaStream(streamRef.current);
          streamRef.current = null;
          setCameraActive(false);
          setMessage('Camera stopped.');
          return;
        }
        if (!videoRef.current) return;
        streamRef.current = await requestCameraPreview(videoRef.current);
        setCameraActive(true);
        setMessage('Camera preview active locally. No image is uploaded or saved by this panel.');
      } else if (id === 'motion') {
        await requestMotionPermission();
        window.addEventListener('devicemotion', handleMotion);
        setMessage('Motion readings enabled for this panel. Close the panel to stop listening.');
      } else if (id === 'vibration') {
        setMessage(requestVibration() ? 'Short vibration requested.' : 'Vibration is unavailable on this device.');
      } else {
        setMessage('This capability is shown for compatibility only. It is not activated by this prototype.');
      }
    } catch (error) {
      setMessage(error instanceof Error ? `Not activated: ${error.message}` : 'Not activated.');
    }
  }

  const label = (state: DeviceCapability['state']) => ({ available: 'AVAILABLE', 'permission-required': 'PERMISSION REQUIRED', unsupported: 'NOT SUPPORTED HERE', unknown: 'UNKNOWN' }[state]);
  return <div className="fixed inset-0 z-[400] overflow-y-auto bg-slate-950/70 p-3 sm:p-6" role="dialog" aria-modal="true" aria-labelledby="device-capabilities-title">
    <section className="mx-auto max-w-3xl rounded-3xl bg-white p-5 shadow-2xl sm:p-8">
      <div className="flex items-start justify-between gap-4">
        <div><p className="text-xs font-black uppercase tracking-widest text-emerald-700">SWI · Device bridge</p><h2 id="device-capabilities-title" className="mt-1 text-2xl font-black">Phone & device capabilities</h2><p className="mt-2 text-sm text-slate-600">Capabilities depend on browser, operating system, hardware, secure context, and permission. Nothing is sampled automatically.</p></div>
        <button className="rounded-xl border px-3 py-2 text-sm font-bold" onClick={onClose}>Close</button>
      </div>
      <div role="status" className="my-5 rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">{message}</div>
      <div className="grid gap-3 sm:grid-cols-2">{capabilities.map((cap) => <article key={cap.id} className="rounded-2xl border border-slate-200 p-4">
        <div className="flex items-start justify-between gap-3"><h3 className="font-extrabold">{cap.label}</h3><span className="text-right text-[10px] font-black tracking-wide text-slate-500">{label(cap.state)}</span></div>
        <p className="mt-2 text-xs leading-relaxed text-slate-600">{cap.note}</p>
        {['geolocation','camera','motion','vibration'].includes(cap.id) && cap.state !== 'unsupported' && <button onClick={() => void useCapability(cap.id)} className="mt-3 rounded-lg bg-slate-900 px-3 py-2 text-xs font-bold text-white">{cap.id === 'camera' && cameraActive ? 'Stop camera' : 'Request / test'}</button>}
        {cap.id === 'geolocation' && location && <p className="mt-2 text-xs text-emerald-700">{location}</p>}
        {cap.id === 'motion' && <p className="mt-2 text-xs text-slate-700">{motion}</p>}
      </article>)}</div>
      <video ref={videoRef} autoPlay muted playsInline className={cameraActive ? 'mt-4 block max-h-64 w-full rounded-xl bg-black' : 'hidden'} />
      <p className="mt-5 border-t pt-4 text-xs leading-relaxed text-slate-500">Privacy boundary: this panel does not run background monitoring, collect biometrics, track students, or send sensor data to a server. Any future attendance, wellbeing, or safety use needs a separately reviewed purpose, consent/authority model, retention rules, and adversarial tests. Sensor output is observation—not identity, truth, or authorization.</p>
    </section>
  </div>;
}
