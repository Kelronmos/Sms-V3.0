# One-click start and offline operation

## Start the application

On Windows, double-click `start.bat`. It checks Node.js, installs the exact dependencies from `package-lock.json` if required, rebuilds the web application, starts the local Express + SQLite server, waits for `/api/health`, and opens `http://127.0.0.1:3000` in the default browser.

Requirements: Windows, Node.js 20+, npm 10+, and PowerShell (included in supported Windows versions).

## First run versus offline runs

- **First setup:** if `node_modules` is absent or incomplete, `npm ci` must download the locked dependencies. Internet access is required for this setup unless the dependencies have already been installed or a prepared dependency cache is available.
- **Later runs:** with dependencies installed, the build and local server run on the same computer and do not require internet access. The SQLite database is stored locally as `samh_swi.db`.
- The built browser shell is configured for PWA precaching, so its HTML, JavaScript, CSS, and matching static assets can be served from the service-worker cache after a successful first load. The local launcher itself still needs the local server running.
- Demo/local API and SQLite functionality can operate offline where the relevant feature uses the local backend or cached data.
- Firebase authentication and Firestore sync, Google/Apple sign-in, cloud AI services, remote images, and external integrations require internet and valid service configuration. They are not simulated as successful when offline. Use the app's demo/local workflow for offline demonstrations.

## Important limitations

This is an offline-capable local prototype, not a complete offline replacement for every cloud feature. PWA caching does not prove data synchronization, security, or production readiness. Data entered on one computer is not automatically synchronized to another. Protect the local database and backups because they may contain sensitive student information. Do not use real student data in an unreviewed prototype.

## Troubleshooting

- If dependency installation fails, connect to the internet and run `start.bat` again.
- If the build fails, the server is deliberately not started. Read the error shown in the launcher window.
- If port 3000 is occupied, close the other process or configure a different port consistently in `server.ts` and the launcher.
- Keep the minimized **SWI Student Monitor Server** window open while using the app. Close that window to stop the server.
