# SWI Student Monitor — physical-device sensor test plan

Status: **TEST PLAN ONLY — no physical-device result is claimed.**

## Devices and builds

Record the exact device model, OS version/build, browser or app version, app commit SHA, build artifact SHA-256, tester, date/time, and permission state. Test at least one supported Android device and one supported iPhone if both are in scope. Browser behavior does not establish native Capacitor plugin behavior.

## Required cases

| ID | Test | Expected observable result | Evidence to record |
|---|---|---|---|
| SENSOR-01 | Open Device panel without pressing any capability button | No location, camera, or motion request is triggered | Screen recording/log; OS permission history |
| SENSOR-02 | Deny location permission | UI reports failure; app does not claim location was obtained | UI result and OS permission state |
| SENSOR-03 | Allow one-time location request | Accuracy summary appears; coordinates are not displayed, persisted, or sent by this panel | Network capture and local-storage/database inspection |
| SENSOR-04 | Deny camera permission | Preview does not start; actionable failure message appears | UI result and OS permission state |
| SENSOR-05 | Allow camera, then stop/close panel | Preview stops and all media tracks end | OS camera indicator and track state |
| SENSOR-06 | Deny motion permission where platform supports a prompt | No motion stream is treated as available; UI reports failure | UI result and OS permission state |
| SENSOR-07 | Allow motion, then close panel | Motion listener is removed and no further readings update | Event/listener observation |
| SENSOR-08 | Request vibration | Only one short, user-triggered vibration occurs when supported | Device observation and UI result |
| SENSOR-09 | Switch airplane mode/network off and on | Network indicator updates; it does not claim backend reachability | UI result plus backend request logs |
| SENSOR-10 | Reopen panel and navigate away | No prior camera stream or motion listener remains active | OS indicators and listener/track inspection |
| SENSOR-11 | Inspect app data after all cases | No sensor history or raw coordinates/media were persisted by this panel | Local storage, app database, and network inspection |

## Pass rule

Every applicable case must have a recorded result and evidence. Unsupported platform features are `NOT SUPPORTED`, not `PASS`. Missing evidence is `NOT VERIFIED`. Any unexpected background collection, unrequested permission prompt, surviving camera stream, or surviving motion listener is a failure and blocks release.

Sensor output is an observation, not identity, attendance proof, diagnosis, admission, authorization, or action. Do not test on students or collect real student data during this validation.
