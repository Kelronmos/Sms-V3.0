# Student Monitor component integration matrix

This is an honest integration inventory, not a certification. A UI component existing in source does not prove its API route, cloud provider, offline path, or security boundary works on every target.

| Component group | Current source / integration | Web/PWA | Desktop local server | Native mobile wrapper | Offline boundary / next verification |
|---|---|---|---|---|---|
| Login and role dashboards | `src/components/Login.tsx`, `StudentDashboard.tsx`, `TeacherDashboard.tsx`, `AdminDashboard.tsx`, `ParentDashboard.tsx` | Existing UI | Existing local server / Firebase paths | UI bundle can be packaged; API/auth parity not verified | Test role enforcement server-side; client role labels are not authority. |
| Student profiles and academic metrics | `src/services/api.ts`, dashboard components | Existing API client | `/api/*` + SQLite routes, selected cache | Requires HTTPS API base or mobile data adapter | Validate cache freshness, conflicts, and privacy. |
| Wellbeing and risk indicators | `WellbeingSummary.tsx`, `CEKMonitor.tsx`, `AdvancedCEK.ts`, `aiEngine.ts` | Existing UI/advisory code | Local API and optional cloud AI | Cloud AI needs internet; native parity not verified | Do not treat heuristic/AI output as diagnosis or authority. |
| Reports and exports | `reportPdf.ts`, `ReportsPanel.tsx`, `MinistryExport.tsx` | Browser-side and API-dependent paths | API/server and browser paths | File-system/share behavior needs native adapter | Test report provenance, access checks, and offline export scope. |
| Communication and incidents | `CommunicationCenter.tsx`, `IncidentReporting.tsx`, API routes | Existing UI/API client | Local API + database | Backend connectivity needed for cross-device messages | Offline queued writes and conflict resolution are not complete. |
| Calendar, timetable, assignments | Corresponding components and API client | Existing UI/API client | Local API/database | Native parity not verified | Test stale cache and merge behavior. |
| SWI workflow guard | `src/services/swiWorkflowGuard.ts` | Helper/tests | Helper/tests | Shared JS helper can be bundled | Guard helper is not a substitute for server-side authorization. |
| Evidence / observations / claims | SWI integration docs and guard | Partial specification | Partial specification | No complete cross-platform evidence store yet | Implement and test durable, tamper-evident evidence before stronger claims. |
| Device capability panel | `src/components/platform/DeviceCapabilitiesPanel.tsx` | Uses supported browser APIs with explicit user actions | Browser/Electron APIs vary | Basic webview capabilities may work; native plugins not yet called by the panel | Geolocation, camera preview, motion and vibration are one-time tests only. |
| Bluetooth LE / NFC / health / step count / biometrics | Capability detection/documentation only | Limited/unsupported depending on browser | Not connected to business logic | Plugin/API and entitlements still need implementation | Explicitly NOT IMPLEMENTED as workflows. No silent/background collection. |
| Cloud sync, Firebase, Google APIs, Gemini | `src/firebase.ts`, API server | Requires configuration/network | Requires configuration/network unless local routes apply | Requires secure backend/configuration | Offline operation does not mean cloud features work offline. |

## Mobile API boundary

The current application contains numerous relative `/api/...` calls. In Capacitor, those URLs resolve to the app's local webview origin unless an API base adapter is introduced. This package does **not** claim all of those routes work on Android/iOS. Before field use, implement and test a single API base/client, authenticated HTTPS CORS policy, and a native/local persistence adapter. Do not embed privileged service credentials in the mobile bundle.
