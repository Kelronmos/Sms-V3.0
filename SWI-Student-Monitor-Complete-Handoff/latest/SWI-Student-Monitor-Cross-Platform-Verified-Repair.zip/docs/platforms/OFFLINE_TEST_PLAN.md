# SWI Student Monitor — offline verification plan

Status: **NOT VERIFIED END TO END.** The PWA configuration is intended to cache the static app shell after an initial successful load. Selected service methods cache selected responses in browser localStorage; this is not a complete offline database.

## Test sequence

1. Build and serve the production web app over HTTPS or localhost.
2. Load the app online, wait for service-worker installation and asset caching, then verify the service worker is active.
3. Close the app, disconnect the network, and reopen it. Record whether the static shell renders without network access.
4. Test each screen and route separately. Mark each route `WORKS OFFLINE`, `READ-ONLY CACHE`, `REQUIRES SERVER`, or `NOT TESTED`.
5. Attempt create/update/delete operations offline. A UI success toast is not proof of persistence; inspect durable storage after closing/reopening the app.
6. Reconnect. Verify whether queued writes are replayed, whether duplicate writes are prevented, and whether conflicts are surfaced rather than silently overwritten.
7. Repeat after browser restart and device restart. Clear site data and confirm the first offline launch behavior.
8. Repeat separately on Android/iOS Capacitor builds. Web/PWA results do not prove native wrapper results.

## Mandatory boundaries

- Cloud AI, Firebase, Google APIs, cross-device sync, and remote services require connectivity unless an explicitly tested local alternative exists.
- Current mobile builds do not include complete native local persistence/API parity with desktop SQLite.
- Existing localStorage caches are not an encrypted database, reliable write queue, or conflict-resolution protocol.
- Do not mark complete offline operation `PASS` until all in-scope screens, reads, writes, restart behavior, sync, and conflict cases have evidence.

## Result record template

| Field | Value |
|---|---|
| Commit SHA | NOT RECORDED |
| Build artifact SHA-256 | NOT RECORDED |
| Device / OS / browser or app | NOT RECORDED |
| Initial online load and service-worker activation | NOT TESTED |
| Offline cold launch | NOT TESTED |
| Offline reads by screen | NOT TESTED |
| Offline writes and durable persistence | NOT TESTED |
| Reconnect / replay / duplicate protection | NOT TESTED |
| Conflict handling | NOT TESTED |
| Overall result | NOT VERIFIED |
