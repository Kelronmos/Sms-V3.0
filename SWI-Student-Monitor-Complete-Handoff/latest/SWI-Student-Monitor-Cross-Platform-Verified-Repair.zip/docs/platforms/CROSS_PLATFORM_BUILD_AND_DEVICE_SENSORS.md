# SWI Student Monitor — Cross-platform build and device capability plan

## Scope

This package prepares a shared React/Vite application for PWA, Capacitor Android/iOS projects, and Electron desktop packaging. It adds a user-opened Device panel that reports browser capability support and permits explicit one-time location, camera preview, motion, and vibration tests. It does not silently collect sensors.

## Current application shape and integration boundary

- Web/PWA: Vite + React + Workbox; static app assets can be cached after first successful install/load.
- Local desktop server: Express + SQLite (`better-sqlite3`) and WebSocket, started by the Windows/macOS/Linux launchers.
- Cloud integrations: Firebase, Google APIs, and Gemini depend on configuration and network/service availability.
- Native mobile wrapper: Capacitor packages the web build, but the existing Express/SQLite backend is a separate Node process and cannot simply run inside a standard iOS/Android webview. Mobile API calls require a configured, reachable HTTPS backend or a deliberately implemented native/local data adapter. Do not claim all `/api/*` workflows work in the mobile wrapper until tested.
- Electron desktop wrapper: starts the local Express server and opens a hardened BrowserWindow. The packaging script is a starting configuration, not a signed installer.

## Build commands

```bash
npm ci
npm run typecheck
npm run test:swi-guard
npm run build
npm run build:android
npm run build:ios
npm run build:desktop
```

- Android: Android Studio, Android SDK, JDK, and a supported Node/npm installation required.
- iOS: macOS, Xcode, and Apple signing configuration required for device installation/distribution.
- macOS desktop: build on macOS for a native signed package.
- Windows desktop: build on Windows for a Windows package.
- PWA: deploy built `dist/` over HTTPS or use localhost. PWA installation/offline cache needs an initial successful load.

## Device capability matrix

| Capability | Web/PWA | Android native | iOS native | Notes |
|---|---|---|---|---|
| Online/offline | Yes | Yes | Yes | Browser network status is an indicator, not proof that the server is reachable. |
| Location | Permission and secure context | Capacitor/native permission needed for full native behavior | Native permission and usage description needed | No background tracking implemented. Coordinates are not persisted by the test panel. |
| Camera | Permission; support varies | Native permission/build configuration required | Native permission/usage description required | Panel only previews locally; stops stream when closed. |
| Motion/orientation | Partial browser support | Native plugin may be required | Permission gesture and native configuration may be required | Not attendance proof, identity, or wellbeing diagnosis. |
| Vibration/haptics | Partial | Native haptics plugin recommended | Native haptics plugin recommended | Explicit test only. |
| Bluetooth LE | Limited browser support | Native plugin and permission required | Native plugin/permission required | Not connected to business workflows yet. |
| NFC | Very limited web support | Native plugin and device hardware required | iOS NFC capabilities/entitlements and native implementation required | Not implemented beyond capability detection. |
| Battery | Limited browser support | Native plugin can expose it | Platform support varies | Not implemented as a workflow input. |
| Step count / health sensors | Not standard across browsers | Native Health Connect / device APIs and permissions | HealthKit entitlement, permission and implementation | Not implemented; never infer health from generic motion data. |
| Biometrics | WebAuthn/passkeys or native auth APIs | Native auth integration required | LocalAuthentication/Face ID configuration required | Not implemented by this package. |

## Privacy and authority boundary

- Sensors are opt-in and user-initiated. This package does not enable background sensor capture.
- Student tracking, attendance proof, wellbeing scoring, or disciplinary decisions must not be based on raw sensor output alone.
- Before adding any sensor-derived workflow: define purpose, legal basis/authority, consent and guardian requirements where applicable, minimization, retention, access controls, threat model, failure behavior, and adversarial tests.
- Sensor output is an observation, not identity, truth, admission, authorization, or action.
- Do not store coordinates, camera media, microphone audio, motion histories, Bluetooth identifiers, or NFC tag contents unless a separately reviewed requirement explicitly needs it.

## Offline boundaries

The PWA caches app-shell assets. Existing service methods cache selected data in localStorage, but this is not a complete offline database, not an encrypted store, and not proof that every workflow works offline. Cross-device synchronization, Firebase, Google APIs, and cloud AI require connectivity. The mobile native wrapper needs a dedicated native persistence adapter and explicit sync/conflict rules before it can claim parity with desktop-local SQLite.

## Verification status

The presence of configs and build commands is not evidence that native builds work. Validate each platform on its own supported toolchain and record exact OS/toolchain versions, commit SHA, commands, results, logs, and limitations. Do not label a platform SEALED or production-authorized from a successful web build.
