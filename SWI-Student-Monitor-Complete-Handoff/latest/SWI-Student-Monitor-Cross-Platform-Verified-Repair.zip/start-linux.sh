#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v node >/dev/null || { echo 'Node.js 20+ is required.'; exit 1; }
command -v npm >/dev/null || { echo 'npm is required.'; exit 1; }
node -e 'if (+process.versions.node.split(".")[0] < 20) process.exit(1)' || { echo 'Node.js 20+ is required.'; exit 1; }
if [ ! -x node_modules/.bin/vite ] || [ ! -x node_modules/.bin/tsx ]; then npm ci; fi
npm run build
HOST=127.0.0.1 NODE_ENV=production npm run start:production & SERVER_PID=$!
trap 'kill "$SERVER_PID" 2>/dev/null || true' EXIT INT TERM
for i in $(seq 1 40); do
  if curl -fsS http://127.0.0.1:3000/api/health >/dev/null; then
    if command -v xdg-open >/dev/null; then xdg-open http://127.0.0.1:3000 >/dev/null 2>&1 || true; fi
    wait "$SERVER_PID"; exit $?
  fi
  sleep 0.5
done
echo 'Server did not become healthy.'; exit 1
