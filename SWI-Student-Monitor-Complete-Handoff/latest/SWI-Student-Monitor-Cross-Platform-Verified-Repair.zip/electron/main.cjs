const { app, BrowserWindow, shell } = require('electron');
const path = require('node:path');
const { spawn } = require('node:child_process');
const http = require('node:http');
let serverProcess;
let mainWindow;
const port = Number(process.env.PORT || 4179);
const root = app.getAppPath();

function healthCheck() {
  return new Promise((resolve) => {
    const req = http.get(`http://127.0.0.1:${port}/api/health`, (res) => {
      res.resume(); resolve(res.statusCode === 200);
    });
    req.on('error', () => resolve(false));
    req.setTimeout(1000, () => { req.destroy(); resolve(false); });
  });
}

async function startServer() {
  if (await healthCheck()) return;
  const entry = path.join(root, 'server.ts');
  const tsxLoader = path.join(root, 'node_modules', 'tsx', 'dist', 'loader.mjs');
  serverProcess = spawn(process.execPath, ['--import', tsxLoader, entry], {
    cwd: app.getPath('userData'),
    env: { ...process.env, NODE_ENV: 'production', PORT: String(port), HOST: '127.0.0.1', ELECTRON_RUN_AS_NODE: '1' },
    stdio: 'inherit',
    windowsHide: true,
  });
  for (let i = 0; i < 40; i++) {
    if (await healthCheck()) return;
    await new Promise((r) => setTimeout(r, 500));
  }
  throw new Error('SWI local server did not become healthy.');
}

async function createWindow() {
  await startServer();
  mainWindow = new BrowserWindow({
    width: 1440, height: 960, minWidth: 900, minHeight: 650,
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true },
  });
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('https://')) shell.openExternal(url);
    return { action: 'deny' };
  });
  await mainWindow.loadURL(`http://127.0.0.1:${port}`);
}

app.whenReady().then(createWindow).catch((err) => { console.error(err); app.quit(); });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('before-quit', () => { if (serverProcess && !serverProcess.killed) serverProcess.kill(); });
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow().catch(console.error); });
