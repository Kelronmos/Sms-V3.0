#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
echo "SWI Student Monitor — macOS one-click launcher"
command -v node >/dev/null || { echo "Install Node.js 20+ first."; read -r -p "Press Enter to close"; exit 1; }
command -v npm >/dev/null || { echo "npm not found. Repair Node.js installation."; read -r -p "Press Enter to close"; exit 1; }
node -e 'if (+process.versions.node.split(".")[0] < 20) process.exit(1)' || { echo "Node.js 20+ required."; exit 1; }
if [ ! -x node_modules/.bin/vite ] || [ ! -x node_modules/.bin/tsx ]; then
  echo "Installing locked dependencies (internet required on first setup)..."
  npm ci
fi
npm run build
HOST=127.0.0.1 NODE_ENV=production npm run start:production &
SERVER_PID=$!
cleanup() { kill "$SERVER_PID" 2>/dev/null || true; }
trap cleanup EXIT INT TERM
for i in $(seq 1 40); do
  if curl -fsS http://127.0.0.1:3000/api/health >/dev/null; then
    open http://127.0.0.1:3000
    echo "Server running. Keep this terminal open while using the app."
    wait "$SERVER_PID"
    exit $?
  fi
  sleep 0.5
done
echo "Server did not become healthy. Check errors above."; exit 1
